# directoryprint
A simple package that prints the current directory with the `ls` command called using Python.

# Intallation
```$ dpkg -i printdir```

# Usage
```printdir```

# License
directoryprint is released under the MIT license. See LICENSE for details.

# Contact
Checkout my other projects at Github, [@christophermilian](https://github.com/christophermilian)